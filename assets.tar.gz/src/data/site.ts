/**
 * Fonte única de verdade da DS Prime.
 * Alterar dados de contato aqui reflete em todo o site (header, footer, schema, WhatsApp).
 */

export const SITE = {
  name: 'DS Prime Transporte Executivo',
  shortName: 'DS Prime',
  url: 'https://dsprimetransporteexecutivo.com.br',
  locale: 'pt-BR',
  founded: '2022',
  description:
    'Transporte executivo em Chapecó com frota própria e motoristas profissionais. Transfer aeroporto, viagens regionais e interestaduais, transporte corporativo e grupos.',
} as const;

export const CONTACT = {
  phoneRaw: '5549998165246',
  phoneDisplay: '(49) 99816-5246',
  phoneLink: 'tel:+5549998165246',
  email: 'contato@dsprimetransporteexecutivo.com.br',
  street: 'Rua Coronel Bertaso, 345',
  district: 'São Cristóvão',
  city: 'Chapecó',
  state: 'SC',
  stateFull: 'Santa Catarina',
  zip: '89803-270',
  country: 'BR',
  cnpj: '46.556.852/0001-60',
  lat: -27.0964,
  lng: -52.6158,
  instagram: 'https://www.instagram.com/dsprimetransporteexecutivo',
  googleBusiness:
    'https://www.google.com/search?q=DS+PRIME+TRANSPORTE+EXECUTIVO+Chapec%C3%B3&kgmid=/g/11w9877ptb#lrd=/g/11w9877ptb,1',
} as const;

export const ADDRESS_FULL = `${CONTACT.street} – ${CONTACT.district}, ${CONTACT.city} – ${CONTACT.state}, CEP ${CONTACT.zip}`;

/** Monta um link de WhatsApp com mensagem pré-preenchida. */
export function wa(message: string): string {
  return `https://api.whatsapp.com/send?phone=${CONTACT.phoneRaw}&text=${encodeURIComponent(message)}`;
}

export const WA = {
  default: wa('Olá! Gostaria de solicitar um atendimento com a DS Prime Transporte Executivo.'),
  executivo: wa('Olá! Gostaria de solicitar um transporte executivo com a DS Prime em Chapecó.'),
  aeroporto: wa('Olá! Gostaria de agendar um transfer para o aeroporto de Chapecó.'),
  viagem: wa('Olá! Gostaria de um orçamento para uma viagem executiva.'),
  corporativo: wa('Olá! Gostaria de falar sobre transporte corporativo para minha empresa.'),
  eventos: wa('Olá! Gostaria de um orçamento de transporte para um evento.'),
  grupo: wa('Olá! Gostaria de um orçamento para transporte de grupo (van ou ônibus).'),
  orcamento: wa('Olá! Gostaria de solicitar um orçamento sem compromisso.'),
} as const;

/* ------------------------------------------------------------------ */
/* Serviços — cada um vira uma página própria otimizada                */
/* ------------------------------------------------------------------ */

export type Servico = {
  slug: string;
  icon: string;
  nav: string;
  titulo: string;
  /** Nome do serviço em minúsculas, para uso no meio de frases. */
  frase: string;
  /** Título completo da faixa de CTA — escrito à mão para evitar frases montadas por template. */
  ctaTitulo: string;
  h1: string;
  metaTitle: string;
  metaDescription: string;
  keywords: string[];
  resumo: string;
  imagem: string;
  wa: string;
  destaque?: boolean;
  intro: string[];
  beneficios: { titulo: string; texto: string }[];
  paraQuem: string[];
  comoFunciona: { passo: string; texto: string }[];
  faq: { q: string; a: string }[];
};

export const SERVICOS: Servico[] = [
  {
    slug: 'transporte-executivo',
    icon: 'car',
    nav: 'Transporte Executivo',
    titulo: 'Transporte Executivo',
    frase: 'transporte executivo',
    ctaTitulo: 'Precisa de um transporte executivo em Chapecó?',
    h1: 'Transporte executivo em Chapecó com motorista profissional',
    metaTitle: 'Transporte Executivo em Chapecó | Motorista Particular',
    metaDescription:
      'Transporte executivo em Chapecó com motorista profissional e veículo exclusivo. Agendamento prévio, pontualidade e discrição. Peça seu orçamento pelo WhatsApp.',
    keywords: [
      'transporte executivo chapecó',
      'motorista particular chapecó',
      'carro executivo com motorista chapecó',
      'transporte particular chapecó',
      'serviço de motorista chapecó',
    ],
    resumo:
      'Motorista profissional, veículo exclusivo e atendimento sob medida para quem valoriza conforto e discrição em cada deslocamento.',
    imagem: 'service-executive',
    wa: WA.executivo,
    destaque: true,
    intro: [
      'O transporte executivo da DS Prime foi desenhado para quem não pode depender do acaso. Cada deslocamento é agendado com antecedência, o veículo é exclusivo e o motorista já conhece o trajeto antes de você entrar no carro.',
      'Atendemos executivos, empresários, profissionais liberais e famílias em Chapecó e em todo o oeste catarinense. A diferença está no planejamento: não existe corrida improvisada, tempo de espera indefinido ou incerteza sobre qual veículo vai chegar.',
    ],
    beneficios: [
      { titulo: 'Veículo exclusivo', texto: 'Nada de corrida compartilhada. O carro é seu durante todo o serviço, climatizado e higienizado antes de cada saída.' },
      { titulo: 'Motorista dedicado', texto: 'Profissional habilitado, discreto e com postura executiva. O mesmo motorista acompanha você do início ao fim do trajeto.' },
      { titulo: 'Agendamento com hora marcada', texto: 'Você define o horário e nós chegamos antes. Sem aplicativo, sem fila, sem surpresa de última hora.' },
      { titulo: 'Atendimento direto', texto: 'Você fala por WhatsApp com quem organiza a operação — sem central automatizada e sem robô no meio do caminho.' },
    ],
    paraQuem: [
      'Executivos com agenda de reuniões em Chapecó e região',
      'Empresários que recebem clientes ou fornecedores na cidade',
      'Profissionais em viagem de negócios que precisam de mobilidade confiável',
      'Famílias em compromissos importantes — casamentos, formaturas, eventos',
      'Quem precisa de um motorista à disposição por período (meio dia ou dia inteiro)',
    ],
    comoFunciona: [
      { passo: 'Você entra em contato', texto: 'Mande uma mensagem no WhatsApp com data, horário, origem e destino. Respondemos em minutos.' },
      { passo: 'Receba a proposta', texto: 'Enviamos o valor fechado e o veículo indicado para o seu tipo de serviço. Sem taxa dinâmica, sem surpresa.' },
      { passo: 'Confirmação e planejamento', texto: 'Confirmado o serviço, o trajeto é planejado e o motorista é designado com antecedência.' },
      { passo: 'No dia', texto: 'O motorista chega antes do horário combinado. Você recebe a confirmação assim que ele estiver no local.' },
    ],
    faq: [
      { q: 'Qual a diferença entre transporte executivo e aplicativo de corrida?', a: 'O transporte executivo é um serviço agendado, com veículo exclusivo e motorista dedicado. Não há tempo de espera indefinido, variação de preço por demanda, compartilhamento de corrida nem incerteza sobre o veículo. É um serviço planejado, com padrão corporativo.' },
      { q: 'Posso contratar um motorista por período?', a: 'Sim. Oferecemos motorista à disposição por meio período ou dia inteiro, ideal para quem tem uma agenda com vários compromissos no mesmo dia em Chapecó e região.' },
      { q: 'O serviço é só para empresas?', a: 'Não. Atendemos empresas, profissionais autônomos e pessoas físicas. O padrão de atendimento é o mesmo em todos os casos.' },
    ],
  },
  {
    slug: 'transfer-aeroporto-chapeco',
    icon: 'plane',
    nav: 'Transfer Aeroporto',
    titulo: 'Transfer Aeroporto Chapecó',
    frase: 'transfer de aeroporto',
    ctaTitulo: 'Vai chegar ou sair pelo aeroporto de Chapecó?',
    h1: 'Transfer para o aeroporto de Chapecó com monitoramento de voo',
    metaTitle: 'Transfer Aeroporto Chapecó (XAP) 24h | DS Prime',
    metaDescription:
      'Transfer para o aeroporto de Chapecó (XAP) com motorista aguardando no desembarque e monitoramento de voo em tempo real. Orçamento em minutos no WhatsApp.',
    keywords: [
      'transfer aeroporto chapecó',
      'motorista aeroporto chapecó',
      'táxi aeroporto chapecó',
      'transporte aeroporto chapecó',
      'transfer aeroporto xap',
      'aeroporto serafim enoss bertaso',
    ],
    resumo:
      'Do aeroporto ao hotel, do hotel ao aeroporto ou do aeroporto para outras cidades — com voo monitorado em tempo real.',
    imagem: 'service-airport',
    wa: WA.aeroporto,
    destaque: true,
    intro: [
      'O Aeroporto Serafim Enoss Bertaso (XAP) é a porta de entrada de Chapecó, e o transfer é o momento em que uma viagem começa bem ou começa errado. A DS Prime monitora o número do seu voo em tempo real: se o voo atrasa, o motorista ajusta o horário e continua esperando. Se adianta, ele já está lá.',
      'Fazemos o trajeto nos dois sentidos — do aeroporto para o hotel, empresa ou residência, e do seu endereço para o aeroporto com folga de tempo suficiente para o check-in. Também atendemos rotas do aeroporto de Chapecó para cidades vizinhas.',
    ],
    beneficios: [
      { titulo: 'Monitoramento de voo em tempo real', texto: 'Acompanhamos o status do seu voo. Atrasou, adiantou ou mudou de portão — o motorista se ajusta sem custo adicional de espera.' },
      { titulo: 'Motorista aguardando na chegada', texto: 'Você desembarca e o motorista já está no saguão. Sem esperar aplicativo, sem negociar corrida no meio-fio.' },
      { titulo: 'Espaço real para bagagem', texto: 'O veículo é designado conforme o número de passageiros e volumes. Van ou ônibus para grupos maiores.' },
      { titulo: 'Transfer para outras cidades', texto: 'Do aeroporto de Chapecó para Xanxerê, Concórdia, Joaçaba, Erechim, Passo Fundo e dezenas de outras cidades.' },
    ],
    paraQuem: [
      'Passageiros chegando ou saindo do aeroporto de Chapecó (XAP)',
      'Empresas que recebem visitantes, diretores ou fornecedores',
      'Hotéis e pousadas que organizam o traslado dos hóspedes',
      'Quem chega em Chapecó e segue para outra cidade da região',
      'Grupos e equipes chegando no mesmo voo',
    ],
    comoFunciona: [
      { passo: 'Informe o voo', texto: 'Envie no WhatsApp o número do voo, data, horário e o endereço de destino.' },
      { passo: 'Receba a confirmação', texto: 'Confirmamos o valor e o veículo. O número do voo entra no nosso monitoramento.' },
      { passo: 'Acompanhamos o status', texto: 'Se o voo atrasar, o horário do motorista é reajustado automaticamente. Você não paga espera por atraso de companhia aérea.' },
      { passo: 'Encontro no desembarque', texto: 'O motorista aguarda no saguão e ajuda com a bagagem. Do desembarque ao destino, sem escala.' },
    ],
    faq: [
      { q: 'Quanto custa o transfer do aeroporto de Chapecó?', a: 'O valor depende do destino: hotel no centro de Chapecó, bairro, empresa ou cidade vizinha. Envie data, horário e destino pelo WhatsApp e você recebe uma proposta fechada em minutos, sem compromisso.' },
      { q: 'E se o meu voo atrasar?', a: 'Monitoramos o status do voo em tempo real. Se houver atraso, o motorista ajusta o horário e continua aguardando — sem cobrança adicional de espera por atraso da companhia aérea.' },
      { q: 'Vocês levam do aeroporto de Chapecó para outras cidades?', a: 'Sim. Atendemos transfer do aeroporto de Chapecó para Xanxerê, Concórdia, Joaçaba, Videira, São Miguel do Oeste, Erechim, Passo Fundo e diversas outras cidades da região. Também fazemos o trajeto inverso.' },
      { q: 'Com quanta antecedência preciso agendar o transfer?', a: 'O ideal é agendar com pelo menos 24 horas de antecedência para garantir disponibilidade. Para grupos ou horários de madrugada, recomendamos 48 horas.' },
      { q: 'O motorista espera no saguão de desembarque?', a: 'Sim. O motorista aguarda no saguão e auxilia com a bagagem até o veículo.' },
    ],
  },
  {
    slug: 'viagens-regionais-interestaduais',
    icon: 'map',
    nav: 'Viagens',
    titulo: 'Viagens Regionais e Interestaduais',
    frase: 'viagens saindo de Chapecó',
    ctaTitulo: 'Vai viajar para fora de Chapecó?',
    h1: 'Viagens executivas de Chapecó para todo o Sul e Sudeste',
    metaTitle: 'Viagens Executivas Saindo de Chapecó | DS Prime',
    metaDescription:
      'Viagens executivas saindo de Chapecó para Florianópolis, Curitiba, Porto Alegre, São Paulo e região. Veículo confortável, motorista experiente e trajeto planejado.',
    keywords: [
      'viagem executiva chapecó',
      'transporte interestadual chapecó',
      'chapecó florianópolis carro',
      'chapecó curitiba transporte',
      'motorista para viagem longa chapecó',
    ],
    resumo:
      'Chapecó a Florianópolis, Curitiba, Passo Fundo, Porto Alegre e dezenas de destinos, com trajeto planejado do início ao fim.',
    imagem: 'service-regional',
    wa: WA.viagem,
    intro: [
      'Viagem longa exige mais do que um carro: exige planejamento. Antes de cada trajeto interestadual, definimos rota, pontos de parada, horário de saída e margem de segurança para imprevistos. Você chega descansado e no horário.',
      'Saindo de Chapecó, atendemos todo o Sul do país e também São Paulo. Sedan executivo para uma ou duas pessoas, SUV para mais conforto e bagagem, van ou ônibus quando o grupo é maior.',
    ],
    beneficios: [
      { titulo: 'Trajeto planejado antes da saída', texto: 'Rota, paradas e horário definidos com antecedência. Sem improviso no meio da estrada.' },
      { titulo: 'Motorista experiente em longa distância', texto: 'Profissionais habituados a trechos longos, com respeito rigoroso a limites de jornada e descanso.' },
      { titulo: 'Conforto real na estrada', texto: 'Veículos climatizados e revisados antes de cada viagem longa. Espaço adequado para bagagem.' },
      { titulo: 'Ida e volta ou só ida', texto: 'Você escolhe. Podemos aguardar no destino ou retornar e buscar na data combinada.' },
    ],
    paraQuem: [
      'Executivos com reunião ou visita técnica em outra cidade',
      'Quem prefere não dirigir em trechos longos',
      'Famílias viajando com bagagem e crianças',
      'Empresas deslocando equipes para outra unidade',
      'Quem precisa chegar em horário fixo, sem depender de conexão aérea',
    ],
    comoFunciona: [
      { passo: 'Conte o trajeto', texto: 'Origem, destino, data de ida e volta, quantas pessoas e volume de bagagem.' },
      { passo: 'Receba a proposta', texto: 'Valor fechado, incluindo pedágio e combustível. Sem custo variável depois.' },
      { passo: 'Planejamento da rota', texto: 'Definimos horário de saída, paradas e margem de tempo para imprevistos.' },
      { passo: 'Viagem', texto: 'Motorista designado, veículo revisado e trajeto acompanhado do começo ao fim.' },
    ],
    faq: [
      { q: 'Vocês fazem viagem de Chapecó para Florianópolis?', a: 'Sim. Chapecó–Florianópolis é uma das nossas rotas mais frequentes, com aproximadamente 550 km. A viagem é planejada com paradas programadas e horário de saída ajustado ao seu compromisso.' },
      { q: 'O valor inclui pedágio e combustível?', a: 'Sim. A proposta enviada é fechada e já inclui combustível, pedágios e a diária do motorista. Não há cobrança extra depois.' },
      { q: 'O motorista aguarda no destino?', a: 'Pode aguardar, se você preferir. Também é possível contratar só a ida e agendar o retorno para outra data — o que costuma reduzir o custo.' },
    ],
  },
  {
    slug: 'transporte-corporativo',
    icon: 'building',
    nav: 'Corporativo',
    titulo: 'Transporte Corporativo',
    frase: 'transporte corporativo',
    ctaTitulo: 'Sua empresa precisa de transporte com padrão?',
    h1: 'Transporte corporativo para empresas em Chapecó',
    metaTitle: 'Transporte Corporativo em Chapecó | DS Prime',
    metaDescription:
      'Transporte corporativo em Chapecó para diretores, equipes e visitantes. Atendimento recorrente, contrato mensal e nota fiscal. Fale com a DS Prime pelo WhatsApp.',
    keywords: [
      'transporte corporativo chapecó',
      'transporte empresarial chapecó',
      'transporte de funcionários chapecó',
      'contrato transporte executivo chapecó',
      'transporte para empresas chapecó',
    ],
    resumo:
      'Soluções contínuas para empresas que precisam de transporte profissional para diretores, equipes e visitantes.',
    imagem: 'service-corporate',
    wa: WA.corporativo,
    intro: [
      'Empresa não pode depender de aplicativo para receber um diretor no aeroporto ou levar uma equipe a uma visita técnica. O transporte corporativo da DS Prime funciona como uma extensão da operação: demanda recorrente, agenda organizada e um contato direto que resolve.',
      'Atendemos indústrias, cooperativas, agroindústrias, escritórios e empresas de tecnologia de Chapecó e região com contratos mensais ou demanda pontual. Emitimos nota fiscal e organizamos relatório de deslocamentos quando necessário.',
    ],
    beneficios: [
      { titulo: 'Contrato recorrente com condições especiais', texto: 'Volume mensal fechado com valores diferenciados e prioridade de agenda.' },
      { titulo: 'Nota fiscal e controle', texto: 'Emissão de NF e relatório de deslocamentos por centro de custo, quando a empresa precisar.' },
      { titulo: 'Recepção de visitantes', texto: 'Diretores, clientes e fornecedores recebidos no aeroporto com a imagem que a sua empresa quer transmitir.' },
      { titulo: 'Agenda organizada', texto: 'Um canal direto de WhatsApp com quem opera. Solicitação hoje, confirmação hoje.' },
    ],
    paraQuem: [
      'Indústrias e agroindústrias que recebem visitantes com frequência',
      'Empresas com diretoria em deslocamento constante',
      'RHs que organizam transporte de equipes para treinamentos e visitas',
      'Escritórios que atendem clientes de fora',
      'Empresas com filiais em outras cidades do Sul',
    ],
    comoFunciona: [
      { passo: 'Entenda a demanda', texto: 'Conversamos sobre o volume mensal, os tipos de deslocamento e quem serão os solicitantes.' },
      { passo: 'Proposta comercial', texto: 'Montamos uma tabela de valores por trajeto ou pacote mensal, conforme o perfil da empresa.' },
      { passo: 'Canal direto', texto: 'Sua equipe passa a solicitar diretamente pelo WhatsApp, com confirmação no mesmo dia.' },
      { passo: 'Operação e faturamento', texto: 'Serviços executados no padrão combinado e faturamento consolidado no fim do mês.' },
    ],
    faq: [
      { q: 'Vocês emitem nota fiscal?', a: 'Sim. Somos empresa constituída (CNPJ 46.556.852/0001-60) e emitimos nota fiscal para todos os serviços corporativos.' },
      { q: 'Existe contrato mensal?', a: 'Sim. Para empresas com demanda recorrente oferecemos contrato mensal com valores diferenciados e prioridade na agenda.' },
      { q: 'Conseguem atender solicitação no mesmo dia?', a: 'Na maioria dos casos, sim — especialmente para clientes com contrato. Ainda assim, quanto antes a solicitação chegar, maior a garantia de disponibilidade do veículo ideal.' },
    ],
  },
  {
    slug: 'eventos-e-congressos',
    icon: 'users',
    nav: 'Eventos',
    titulo: 'Eventos e Congressos',
    frase: 'transporte para eventos',
    ctaTitulo: 'Tem um evento para organizar em Chapecó?',
    h1: 'Transporte para eventos, congressos e casamentos em Chapecó',
    metaTitle: 'Transporte para Eventos e Congressos em Chapecó',
    metaDescription:
      'Logística de transporte para congressos, convenções, casamentos e formaturas em Chapecó. Múltiplos veículos com horários sincronizados. Peça orçamento no WhatsApp.',
    keywords: [
      'transporte para eventos chapecó',
      'transporte casamento chapecó',
      'transporte congresso chapecó',
      'van para evento chapecó',
      'transporte formatura chapecó',
    ],
    resumo:
      'Logística completa para congressos, convenções, casamentos e formaturas, com múltiplos veículos sincronizados.',
    imagem: 'service-events',
    wa: WA.eventos,
    intro: [
      'Em evento, transporte não é detalhe: é o que define se as pessoas chegam juntas e no horário. A DS Prime organiza a logística inteira — quantos veículos, quais horários, quais pontos de embarque e quem coordena no dia.',
      'Já atendemos congressos, convenções empresariais, casamentos, formaturas e eventos esportivos em Chapecó e região, com operações que vão de um sedan a uma frota de vans e ônibus rodando em paralelo.',
    ],
    beneficios: [
      { titulo: 'Coordenação de múltiplos veículos', texto: 'Vans, ônibus e sedans operando com horários sincronizados e um responsável único pela operação.' },
      { titulo: 'Planejamento de embarque', texto: 'Pontos de embarque definidos, lista de passageiros e horários confirmados antes do dia do evento.' },
      { titulo: 'Shuttle contínuo', texto: 'Circuito entre hotel e local do evento com saídas em intervalos fixos durante todo o período.' },
      { titulo: 'Um contato para tudo', texto: 'Você fala com uma pessoa que responde por toda a operação de transporte — não com vários motoristas soltos.' },
    ],
    paraQuem: [
      'Organizadores de congressos e convenções em Chapecó',
      'Noivos e cerimonialistas que precisam levar convidados',
      'Comissões de formatura',
      'Empresas com convenção anual ou encontro de equipe',
      'Times e delegações esportivas',
    ],
    comoFunciona: [
      { passo: 'Briefing do evento', texto: 'Data, número de pessoas, pontos de embarque, local e horários do evento.' },
      { passo: 'Desenho da operação', texto: 'Definimos quantos veículos, quais tipos e a grade de horários necessária.' },
      { passo: 'Proposta fechada', texto: 'Valor consolidado da operação completa, com tudo especificado.' },
      { passo: 'Execução coordenada', texto: 'No dia, os veículos operam conforme a grade e você tem um responsável direto para qualquer ajuste.' },
    ],
    faq: [
      { q: 'Vocês atendem casamentos?', a: 'Sim. Fazemos o transporte dos noivos, dos padrinhos e dos convidados, com veículos definidos conforme o número de pessoas e a distância entre a cerimônia e a festa.' },
      { q: 'Conseguem operar shuttle contínuo durante um congresso?', a: 'Sim. Montamos um circuito entre os hotéis e o local do evento com saídas em intervalos fixos ao longo do dia.' },
      { q: 'Com quanta antecedência devo fechar o transporte do evento?', a: 'Para eventos, o ideal é fechar com pelo menos 15 dias de antecedência — especialmente em datas de alta demanda, como período de formaturas e congressos regionais.' },
    ],
  },
  {
    slug: 'van-e-onibus-para-grupos',
    icon: 'bus',
    nav: 'Van e Ônibus',
    titulo: 'Van e Ônibus Executivos',
    frase: 'van ou ônibus para grupos',
    ctaTitulo: 'Precisa levar um grupo inteiro junto?',
    h1: 'Van e ônibus executivos para grupos em Chapecó',
    metaTitle: 'Van e Ônibus para Grupos em Chapecó | DS Prime',
    metaDescription:
      'Van executiva e ônibus para transporte de grupos em Chapecó e região. Climatizados, com motorista profissional e logística organizada. Orçamento rápido no WhatsApp.',
    keywords: [
      'van executiva chapecó',
      'aluguel de van com motorista chapecó',
      'ônibus fretado chapecó',
      'fretamento chapecó',
      'transporte de grupos chapecó',
    ],
    resumo:
      'Estrutura própria para grupos de qualquer tamanho. Vans e ônibus climatizados com motorista profissional.',
    imagem: 'service-van',
    wa: WA.grupo,
    intro: [
      'Quando o grupo cresce, dividir em vários carros vira um problema de coordenação. A van executiva e o ônibus resolvem isso: todo mundo junto, no mesmo horário, com um motorista responsável pelo trajeto.',
      'Trabalhamos com vans executivas climatizadas e ônibus para grupos maiores, atendendo desde deslocamentos dentro de Chapecó até viagens interestaduais com o grupo completo.',
    ],
    beneficios: [
      { titulo: 'Grupo inteiro junto', texto: 'Sem dividir em vários carros, sem alguém chegando atrasado, sem coordenação por grupo de WhatsApp.' },
      { titulo: 'Veículos climatizados', texto: 'Vans e ônibus com ar-condicionado, revisados e higienizados antes de cada saída.' },
      { titulo: 'Motorista profissional', texto: 'Habilitado na categoria adequada e experiente em transporte coletivo de passageiros.' },
      { titulo: 'Custo por pessoa menor', texto: 'Para grupos, o transporte coletivo sai bem mais em conta do que vários veículos individuais.' },
    ],
    paraQuem: [
      'Equipes de empresa em treinamento ou visita técnica',
      'Excursões e viagens de grupo saindo de Chapecó',
      'Times, delegações e grupos esportivos',
      'Famílias grandes em viagem conjunta',
      'Grupos chegando no mesmo voo no aeroporto de Chapecó',
    ],
    comoFunciona: [
      { passo: 'Informe o grupo', texto: 'Quantas pessoas, data, origem, destino e se há bagagem volumosa.' },
      { passo: 'Indicação do veículo', texto: 'Indicamos van ou ônibus conforme o número de passageiros e o trajeto.' },
      { passo: 'Proposta fechada', texto: 'Valor total do serviço, já com combustível, pedágio e motorista.' },
      { passo: 'Embarque organizado', texto: 'Pontos e horários de embarque definidos, com o motorista chegando antes.' },
    ],
    faq: [
      { q: 'Quantas pessoas cabem na van executiva?', a: 'Nossas vans executivas acomodam confortavelmente grupos de até 15 passageiros com bagagem. Para grupos maiores, indicamos o ônibus.' },
      { q: 'Vocês fazem fretamento para outras cidades?', a: 'Sim. Fazemos fretamento de van e ônibus saindo de Chapecó para qualquer destino do Sul e Sudeste, com valor fechado incluindo combustível e pedágios.' },
      { q: 'É possível contratar van com motorista por vários dias?', a: 'Sim. Para excursões e eventos de vários dias montamos uma operação com o veículo e o motorista à disposição do grupo durante todo o período.' },
    ],
  },
];

/* ------------------------------------------------------------------ */
/* Rotas — páginas de long-tail geográfico                             */
/* ------------------------------------------------------------------ */

export type Rota = {
  slug: string;
  destino: string;
  uf: string;
  distancia: string;
  duracao: string;
  imagem: string;
  /** O que a foto realmente retrata — usado no alt, para não descrever a imagem errada. */
  imagemAlt: string;
  metaTitle: string;
  metaDescription: string;
  keywords: string[];
  intro: string[];
  cidades: string[];
  observacao: string;
  /** Pergunta e resposta exclusivas desta rota, para as páginas não ficarem idênticas. */
  faqExtra: { q: string; a: string };
};

export const ROTAS: Rota[] = [
  {
    slug: 'chapeco-florianopolis',
    destino: 'Florianópolis',
    uf: 'SC',
    distancia: '≈ 550 km',
    duracao: '≈ 7h de viagem',
    imagem: 'route-sc',
    imagemAlt: 'Balneário Camboriú, no litoral de Santa Catarina, um dos destinos atendidos na rota',
    metaTitle: 'Chapecó → Florianópolis | Transporte Executivo',
    metaDescription:
      'Viagem executiva de Chapecó para Florianópolis com motorista profissional e veículo confortável. Valor fechado com pedágio e combustível. Orçamento no WhatsApp.',
    keywords: ['chapecó florianópolis carro', 'transporte chapecó florianópolis', 'motorista chapecó florianópolis', 'viagem executiva florianópolis'],
    intro: [
      'A rota Chapecó–Florianópolis é uma das mais pedidas da DS Prime. São cerca de 550 km pela BR-282, com trechos de serra que pedem um motorista habituado ao trajeto.',
      'Planejamos horário de saída conforme o seu compromisso na capital, com paradas programadas e margem de tempo para imprevistos. Ideal para quem tem reunião, consulta médica, embarque no aeroporto de Florianópolis ou compromisso com hora marcada.',
    ],
    cidades: ['Florianópolis', 'São José', 'Palhoça', 'Biguaçu', 'Balneário Camboriú', 'Itajaí', 'Blumenau', 'Joinville', 'Lages', 'Criciúma'],
    observacao: 'Também atendemos o Aeroporto Internacional Hercílio Luz (FLN), com monitoramento do horário do voo.',
    faqExtra: {
      q: 'A viagem Chapecó–Florianópolis passa por trecho de serra?',
      a: 'Sim. A BR-282 atravessa trechos de serra na região de Bom Retiro e Alfredo Wagner, com neblina frequente no inverno. Por isso designamos motoristas que já conhecem o trajeto e ajustamos o horário de saída para evitar os períodos de menor visibilidade.',
    },
  },
  {
    slug: 'chapeco-curitiba',
    destino: 'Curitiba',
    uf: 'PR',
    distancia: '≈ 480 km',
    duracao: '≈ 6h de viagem',
    imagem: 'route-pr',
    imagemAlt: 'Jardim Botânico de Curitiba, no Paraná',
    metaTitle: 'Chapecó → Curitiba | Transporte Executivo | DS Prime',
    metaDescription:
      'Viagem executiva de Chapecó para Curitiba com motorista experiente e trajeto planejado. Valor fechado, veículo climatizado. Solicite orçamento pelo WhatsApp.',
    keywords: ['chapecó curitiba transporte', 'viagem chapecó curitiba', 'motorista chapecó curitiba', 'transporte executivo curitiba'],
    intro: [
      'Chapecó–Curitiba são aproximadamente 480 km, atravessando o sudoeste do Paraná. É um trajeto que, feito de carro próprio, costuma custar caro em cansaço.',
      'Com a DS Prime, você trabalha, descansa ou se prepara para a reunião enquanto o motorista cuida da estrada. Atendemos também o Aeroporto Afonso Pena (CWB) e a região metropolitana.',
    ],
    cidades: ['Curitiba', 'São José dos Pinhais', 'Ponta Grossa', 'Cascavel', 'Foz do Iguaçu', 'Londrina', 'Maringá', 'Pato Branco', 'Francisco Beltrão'],
    observacao: 'Transfer para o Aeroporto Afonso Pena (CWB) com horário calculado a partir do seu voo.',
    faqExtra: {
      q: 'Dá para incluir uma parada em Cascavel ou Pato Branco no caminho?',
      a: 'Sim. Cascavel, Pato Branco e Francisco Beltrão ficam no trajeto Chapecó–Curitiba e podem entrar como parada ou como destino intermediário. Informe no pedido de orçamento para que o horário de saída seja calculado com essa parada incluída.',
    },
  },
  {
    slug: 'chapeco-porto-alegre',
    destino: 'Porto Alegre',
    uf: 'RS',
    distancia: '≈ 470 km',
    duracao: '≈ 6h de viagem',
    imagem: 'route-rs',
    imagemAlt: 'Gramado, na Serra Gaúcha, um dos destinos atendidos na rota',
    metaTitle: 'Chapecó → Porto Alegre | Transporte Executivo',
    metaDescription:
      'Transporte executivo de Chapecó para Porto Alegre e região. Motorista profissional, veículo confortável e valor fechado. Peça seu orçamento no WhatsApp.',
    keywords: ['chapecó porto alegre transporte', 'viagem chapecó porto alegre', 'motorista chapecó porto alegre', 'transporte executivo rio grande do sul'],
    intro: [
      'A rota Chapecó–Porto Alegre percorre cerca de 470 km pelo norte gaúcho, passando por Erechim e Passo Fundo — trechos que também atendemos individualmente.',
      'Seja para uma reunião na capital, um procedimento médico ou embarque no Aeroporto Salgado Filho, o trajeto é planejado com antecedência e horário definido conforme o seu compromisso.',
    ],
    cidades: ['Porto Alegre', 'Caxias do Sul', 'Gramado', 'Canela', 'Passo Fundo', 'Erechim', 'Bento Gonçalves', 'Novo Hamburgo', 'Santa Maria'],
    observacao: 'Atendemos também o Aeroporto Salgado Filho (POA) e a Serra Gaúcha.',
    faqExtra: {
      q: 'Vocês atendem só Erechim ou Passo Fundo, sem seguir até Porto Alegre?',
      a: 'Sim. Erechim e Passo Fundo estão no trajeto e são destinos frequentes por si só — cerca de 2h e 3h de Chapecó, respectivamente. O valor desses trechos é bem menor que o da viagem completa até a capital.',
    },
  },
  {
    slug: 'chapeco-sao-paulo',
    destino: 'São Paulo',
    uf: 'SP',
    distancia: '≈ 1.000 km',
    duracao: '≈ 13h de viagem',
    imagem: 'route-sp',
    imagemAlt: 'Ponte Estaiada Octávio Frias de Oliveira, em São Paulo',
    metaTitle: 'Chapecó → São Paulo | Transporte Executivo | DS Prime',
    metaDescription:
      'Viagem executiva de Chapecó para São Paulo com planejamento completo de rota e paradas. Veículo confortável e motorista experiente. Orçamento pelo WhatsApp.',
    keywords: ['chapecó são paulo transporte', 'viagem chapecó são paulo carro', 'transporte executivo são paulo', 'motorista chapecó são paulo'],
    intro: [
      'São aproximadamente 1.000 km entre Chapecó e São Paulo. É uma viagem longa, e por isso mesmo a que mais exige planejamento: horário de saída, paradas, revezamento e margem para trânsito na chegada à capital.',
      'Atendemos a capital, a região metropolitana e os aeroportos de Guarulhos (GRU) e Congonhas (CGH), com o horário calculado a partir do seu embarque.',
    ],
    cidades: ['São Paulo', 'Guarulhos', 'Campinas', 'Santos', 'São José dos Campos', 'Sorocaba', 'Ribeirão Preto', 'ABC Paulista'],
    observacao: 'Transfer para Guarulhos (GRU) e Congonhas (CGH) com margem de tempo calculada sobre o horário do voo.',
    faqExtra: {
      q: 'Uma viagem de 13 horas é feita por um motorista só?',
      a: 'Respeitamos rigorosamente os limites de jornada e descanso. Em trajetos longos como Chapecó–São Paulo, a viagem é planejada com paradas obrigatórias de descanso e, dependendo do horário contratado, com revezamento de motorista. Isso entra na proposta desde o início.',
    },
  },
];

/* ------------------------------------------------------------------ */
/* Cidades atendidas na região (SEO local)                             */
/* ------------------------------------------------------------------ */

export const CIDADES_REGIAO = [
  'Xanxerê', 'Xaxim', 'Concórdia', 'Joaçaba', 'Videira', 'São Miguel do Oeste',
  'Pinhalzinho', 'Maravilha', 'Seara', 'São Lourenço do Oeste', 'Palmitos',
  'Coronel Freitas', 'Quilombo', 'Campos Novos', 'Caçador', 'Erechim (RS)',
  'Passo Fundo (RS)', 'Marcelino Ramos (RS)', 'Pato Branco (PR)', 'Francisco Beltrão (PR)',
];

/* ------------------------------------------------------------------ */
/* Frota                                                               */
/* ------------------------------------------------------------------ */

export const FROTA = [
  { nome: 'BYD King GS', img: 'byd', categoria: 'Sedan Executivo', passageiros: 'até 4 passageiros', nota: 'Híbrido, silencioso e econômico — o preferido para trajetos urbanos e transfers.' },
  { nome: 'Toyota Corolla', img: 'corolla', categoria: 'Sedan Executivo', passageiros: 'até 4 passageiros', nota: 'Confiabilidade comprovada em estrada. Escolha padrão para viagens longas.' },
  { nome: 'Chevrolet Cruze', img: 'cruze', categoria: 'Sedan Executivo', passageiros: 'até 4 passageiros', nota: 'Conforto de rodagem e porta-malas amplo para bagagem de mão e mala grande.' },
  { nome: 'Jeep Compass', img: 'jeep', categoria: 'SUV Executivo', passageiros: 'até 4 passageiros', nota: 'Mais espaço interno e altura de embarque confortável. Ideal em dias de chuva.' },
  { nome: 'Van Executiva', img: 'van', categoria: 'Grupos e Eventos', passageiros: 'até 15 passageiros', nota: 'Climatizada, com espaço de bagagem separado. A opção para equipes e famílias.' },
  { nome: 'Ônibus Executivo', img: 'onibus', categoria: 'Grandes Grupos', passageiros: 'grupos maiores', nota: 'Para congressos, excursões e delegações. Operação com logística completa.' },
];

/* ------------------------------------------------------------------ */
/* Diferenciais e itens inclusos                                       */
/* ------------------------------------------------------------------ */

export const INCLUSO = [
  { icon: 'calendar', texto: 'Planejamento completo de cada viagem, definido com antecedência' },
  { icon: 'clock', texto: 'Pontualidade real — o motorista chega antes do horário combinado' },
  { icon: 'user', texto: 'Motorista profissional, discreto e com postura executiva' },
  { icon: 'car', texto: 'Veículo exclusivo, climatizado e higienizado antes de cada serviço' },
  { icon: 'message', texto: 'Comunicação direta por WhatsApp, com resposta em minutos' },
  { icon: 'radar', texto: 'Monitoramento de voo em tempo real nos transfers de aeroporto' },
  { icon: 'check', texto: 'Logística personalizada conforme a necessidade de cada cliente' },
];

export const DIFERENCIAIS = [
  { titulo: 'Motoristas próprios', desc: 'Experientes, habilitados e com postura executiva. Nenhum serviço é terceirizado — quem dirige é da casa.' },
  { titulo: 'Planejamento antecipado', desc: 'Cada viagem é organizada antes: trajeto, horário e logística definidos previamente, sem improviso.' },
  { titulo: 'Pontualidade como padrão', desc: 'Chegamos antes. Seu voo, sua reunião ou seu compromisso não espera — e nós sabemos disso.' },
  { titulo: 'Atendimento direto', desc: 'Sem central de atendimento e sem robô. Você fala por WhatsApp direto com quem organiza a operação.' },
  { titulo: 'Frota própria e revisada', desc: 'Veículos próprios, revisados periodicamente e prontos tanto para trajetos curtos quanto para viagens longas.' },
  { titulo: 'Estrutura para qualquer demanda', desc: 'Do sedan executivo individual ao ônibus para grandes grupos — com o mesmo padrão de organização.' },
];

/* ------------------------------------------------------------------ */
/* FAQ geral (home)                                                    */
/* ------------------------------------------------------------------ */

export const FAQ_GERAL = [
  {
    q: 'Qual a diferença entre transporte executivo e Uber ou táxi em Chapecó?',
    a: 'O transporte executivo da DS Prime é um serviço agendado, com veículo exclusivo, motorista dedicado e monitoramento de voo nos transfers. Não há compartilhamento de corrida, tempo de espera indefinido, variação de preço por demanda ou incerteza sobre o veículo. É um serviço planejado, com padrão corporativo.',
  },
  {
    q: 'Quanto custa o transfer do aeroporto de Chapecó?',
    a: 'O valor varia conforme o destino: hotel no centro, bairro, empresa ou cidade vizinha. Envie data, horário e destino pelo WhatsApp e você recebe uma proposta fechada em minutos, sem compromisso.',
  },
  {
    q: 'Vocês fazem transporte do aeroporto de Chapecó para outras cidades?',
    a: 'Sim. Realizamos transfer do aeroporto de Chapecó para Xanxerê, Concórdia, Joaçaba, Videira, São Miguel do Oeste, Erechim, Passo Fundo e diversas outras cidades da região. Também fazemos o trajeto inverso, de qualquer cidade para o aeroporto.',
  },
  {
    q: 'Fazem transfer do hotel para o aeroporto?',
    a: 'Sim. Buscamos no hotel, pousada ou endereço indicado com a antecedência necessária para você chegar ao aeroporto com tranquilidade. O motorista acompanha o horário do voo para ajustar a logística.',
  },
  {
    q: 'Qual a antecedência necessária para agendar?',
    a: 'Recomendamos pelo menos 24 horas de antecedência para garantir disponibilidade de veículo. Para eventos, grupos ou viagens de longa distância, o ideal é agendar com 48 a 72 horas.',
  },
  {
    q: 'Quais veículos estão disponíveis na frota?',
    a: 'A frota própria inclui sedans executivos (BYD King GS, Toyota Corolla, Chevrolet Cruze), SUV (Jeep Compass), vans executivas e ônibus. Todos revisados, climatizados e higienizados. O veículo é designado conforme o serviço e o número de passageiros.',
  },
  {
    q: 'Vocês atendem empresas e contratos corporativos?',
    a: 'Sim. Oferecemos atendimento contínuo para empresas com demanda regular — recepção de diretores, deslocamento de equipes e apoio a eventos corporativos, com nota fiscal e condições especiais para contratos recorrentes.',
  },
  {
    q: 'Os motoristas são profissionais habilitados?',
    a: 'Todos os motoristas da DS Prime são experientes, habilitados na categoria adequada e preparados para um atendimento discreto, seguro e pontual. Nenhum serviço é terceirizado.',
  },
  {
    q: 'Atendem viagens de longa distância?',
    a: 'Sim. Realizamos viagens executivas como Chapecó–Florianópolis, Chapecó–Curitiba, Chapecó–Porto Alegre e Chapecó–São Paulo, além de rotas sob demanda, sempre com planejamento completo do trajeto.',
  },
  {
    q: 'O serviço é apenas para executivos e empresas?',
    a: 'Não. Atendemos qualquer pessoa que valorize pontualidade, conforto e atendimento profissional — viagens pessoais, familiares, casamentos, formaturas e eventos. O padrão de serviço é o mesmo para todos.',
  },
  {
    q: 'Como funciona o pagamento?',
    a: 'Aceitamos PIX, transferência, cartão e faturamento para clientes corporativos com contrato. O valor é fechado na proposta, sem cobrança adicional depois do serviço.',
  },
  {
    q: 'Vocês atendem de madrugada e em finais de semana?',
    a: 'Sim. Operamos 24 horas por dia, todos os dias da semana. Voos de madrugada e compromissos em fim de semana são atendidos normalmente, desde que agendados com antecedência.',
  },
];
