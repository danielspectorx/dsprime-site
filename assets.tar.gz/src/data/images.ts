import type { ImageMetadata } from 'astro';

/* Frota */
import byd from '../assets/fleet/byd.jpg';
import corolla from '../assets/fleet/corolla.jpg';
import cruze from '../assets/fleet/cruze.jpg';
import jeep from '../assets/fleet/jeep.jpg';
import van from '../assets/fleet/van.jpg';
import onibus from '../assets/fleet/onibus.jpg';

/* Serviços */
import serviceExecutive from '../assets/servicos/service-executive.jpg';
import serviceAirport from '../assets/servicos/service-airport.jpg';
import serviceRegional from '../assets/servicos/service-regional.jpg';
import serviceCorporate from '../assets/servicos/service-corporate.jpg';
import serviceEvents from '../assets/servicos/service-events.jpg';
import serviceVan from '../assets/servicos/service-van.jpg';

/* Rotas */
import routeSC from '../assets/rotas/route-sc.jpg';
import routePR from '../assets/rotas/route-pr.jpg';
import routeRS from '../assets/rotas/route-rs.jpg';
import routeSP from '../assets/rotas/route-sp.jpg';

/* Hero */
import heroBg from '../assets/hero-bg.jpg';

export const IMAGES: Record<string, ImageMetadata> = {
  byd, corolla, cruze, jeep, van, onibus,
  'service-executive': serviceExecutive,
  'service-airport': serviceAirport,
  'service-regional': serviceRegional,
  'service-corporate': serviceCorporate,
  'service-events': serviceEvents,
  'service-van': serviceVan,
  'route-sc': routeSC,
  'route-pr': routePR,
  'route-rs': routeRS,
  'route-sp': routeSP,
  'hero-bg': heroBg,
};

export { heroBg };
